package com.example.app_integracion;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app_integracion.adapter.ChatAdapter;
import com.example.app_integracion.model.Message;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    RecyclerView rvChat;
    ChatAdapter adapter;
    EditText etMessage;
    ImageButton btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_Dark);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        rvChat = findViewById(R.id.recyclerChat);
        etMessage = findViewById(R.id.editMessage);
        btnSend = findViewById(R.id.btnSend);

        rvChat.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChatAdapter(sampleMessages());
        rvChat.setAdapter(adapter);
        // scroll to bottom when layout set
        rvChat.scrollToPosition(adapter.getItemCount() - 1);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(text)) {
                    // Agrega mensaje del usuario (outgoing)
                    Message m = new Message(text, Message.TYPE_OUTGOING);
                    adapter.addMessage(m);
                    rvChat.scrollToPosition(adapter.getItemCount() - 1);
                    etMessage.setText("");

                    // Simula respuesta de IA (frontend only)
                    rvChat.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Message ai = new Message("Respuesta simulada de Ehealth AI sobre opciones terapéuticas.", Message.TYPE_INCOMING);
                            adapter.addMessage(ai);
                            rvChat.scrollToPosition(adapter.getItemCount() - 1);
                        }
                    }, 700);
                }
            }
        });
    }

    private List<Message> sampleMessages() {
        List<Message> list = new ArrayList<>();
        list.add(new Message("Hola, soy Ehealth — ¿en qué puedo ayudarte hoy con tu tratamiento?", Message.TYPE_INCOMING));
        return list;
    }
}
