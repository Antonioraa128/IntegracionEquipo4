package com.example.app_integracion.model;

public class Message {
    public static final int TYPE_INCOMING = 0;
    public static final int TYPE_OUTGOING = 1;

    private String text;
    private int type;

    public Message(String text, int type) {
        this.text = text;
        this.type = type;
    }

    public String getText() { return text; }
    public int getType() { return type; }
}
