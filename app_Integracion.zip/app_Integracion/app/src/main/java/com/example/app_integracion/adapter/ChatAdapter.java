package com.example.app_integracion.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app_integracion.R;
import com.example.app_integracion.model.Message;
import java.util.ArrayList;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final List<Message> messages = new ArrayList<>();

    public ChatAdapter(List<Message> initial) {
        if (initial != null) messages.addAll(initial);
    }

    public void addMessage(Message m) {
        messages.add(m);
        notifyItemInserted(messages.size() - 1);
    }

    @Override
    public int getItemViewType(int position) {
        return messages.get(position).getType();
    }

    @Override
    public int getItemCount() { return messages.size(); }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == Message.TYPE_INCOMING) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_incoming, parent, false);
            return new IncomingHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_outgoing, parent, false);
            return new OutgoingHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message m = messages.get(position);
        if (holder instanceof IncomingHolder) {
            ((IncomingHolder) holder).txt.setText(m.getText());
        } else {
            ((OutgoingHolder) holder).txt.setText(m.getText());
        }
    }

    static class IncomingHolder extends RecyclerView.ViewHolder {
        TextView txt;
        IncomingHolder(@NonNull View v) { super(v); txt = v.findViewById(R.id.txtMessage); }
    }

    static class OutgoingHolder extends RecyclerView.ViewHolder {
        TextView txt;
        OutgoingHolder(@NonNull View v) { super(v); txt = v.findViewById(R.id.txtMessage); }
    }
}
